* `similar.py`: test correctness, memory, and speed for the similarity function.
* `weighting.py`: test correctness, memory, and speed for the weighting function.
* `module.py`: test memory, and speed for the image local attention module.
* `denoise.py`: train denoise model on CIFAR10.
* `test.sh`: run all test scripts.