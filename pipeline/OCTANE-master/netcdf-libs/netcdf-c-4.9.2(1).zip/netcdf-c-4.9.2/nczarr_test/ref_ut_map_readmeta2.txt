/meta2/.nczarray: |{
"foo": 42,
"bar": "apples",
"baz": [1, 2, 3, 4],
"extra": 137}|
